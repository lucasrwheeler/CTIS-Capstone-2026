// /lambda/plan/index.js

const { GRAPH, getAllDependencies } = require('./dependencyGraph');
const { canTakeInTerm } = require('./semesterLogic');
const { removeCompleted, sortByDependencyDepth } = require('./utils');
const { getClient } = require('./db');

exports.handler = async (event) => {
  const client = getClient();

  try {
    await client.connect();   // ⭐ DB CONNECT

    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const { completed, upcomingTerm } = body || {};

    if (!completed) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Missing 'completed' field." })
      };
    }

    // ⭐ Optional DB test query
    const testQuery = await client.query("SELECT NOW() as server_time");

    const term = upcomingTerm || "Fall";

    const allCourses = Object.keys(GRAPH);
    const remaining = removeCompleted(allCourses, completed);

    const eligibleThisTerm = remaining.filter(c =>
      canTakeInTerm(c, completed, term)
    );

    const sorted = sortByDependencyDepth(eligibleThisTerm, getAllDependencies);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        upcomingTerm: term,
        recommended_courses: sorted,
        db_time: testQuery.rows[0].server_time   // ⭐ proves DB works
      })
    };

  } catch (err) {
    console.error("Plan Lambda error:", err);

    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message })
    };

  } finally {
    await client.end();   // ⭐ DB DISCONNECT
  }
};