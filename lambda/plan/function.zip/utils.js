// -----------------------------
// PREREQUISITES MAP
// -----------------------------
const PREREQS = {
  "CTIS 310": [["CTIS 210"]],
  "CTIS 320": [["CTIS 221"], ["CTIS 210"]],
  "CTIS 321": [["CTIS 210"], ["CTIS 221"]],
  "CTIS 322": [["CTIS 321"]],
  "CTIS 342": [["CTIS 210"], ["CTIS 243"]],
  "CTIS 345": [["CTIS 210"], ["CTIS 243"]],
  "CTIS 370": [["CTIS 221"]],
  "CTIS 371": [["CTIS 221"]],
  "CTIS 440": [["CTIS 321"], ["CTIS 310"], ["CTIS 342"]],
  "CTIS 471": [["CTIS 370"]]
};

const ALL_COURSES = Object.keys(PREREQS);

// -----------------------------
// PLAN LOGIC HELPERS
// -----------------------------
function removeCompleted(courses, completed) {
  return courses.filter(c => !completed.includes(c));
}

function sortByDependencyDepth(courses, getAllDependencies) {
  return [...courses].sort((a, b) => {
    const depthA = getAllDependencies(a).length;
    const depthB = getAllDependencies(b).length;
    return depthA - depthB;
  });
}

// -----------------------------
module.exports = {
  PREREQS,
  ALL_COURSES,
  removeCompleted,
  sortByDependencyDepth
};